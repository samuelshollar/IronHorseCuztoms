# Iron Horse Cuztoms Website

A responsive, static website for GitHub Pages.

## Publish on GitHub Pages
1. Create a GitHub repository named `iron-horse-cuztoms` (or use an existing repository).
2. Upload `index.html`, `style.css`, and the `assets` folder to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. After GitHub finishes publishing, open the URL shown in the Pages settings.

## Customize
- Replace `assets/iron-horse-cuztoms-logo.jpg` to change the logo.
- Update the service descriptions in `index.html` to match the services actually offered.
- The Instagram links point to `https://www.instagram.com/ironhorsecuztoms/`.
- This is a static site; it does not include a booking system or contact form.
